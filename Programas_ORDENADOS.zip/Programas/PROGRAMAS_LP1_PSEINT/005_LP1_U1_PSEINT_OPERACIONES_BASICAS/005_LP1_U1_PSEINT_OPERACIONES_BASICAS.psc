Algoritmo OperacionesBasicas
    Definir a, b, suma, resta, multiplicacion Como Entero
    
    Escribir "Ingrese el primer n�mero:"
    Leer a
    
    Escribir "Ingrese el segundo n�mero:"
    Leer b
    
    suma <- a + b
    resta <- a - b
    multiplicacion <- a * b
	division <- a / b
    
    Escribir "Suma: ", suma
    Escribir "Resta: ", resta
    Escribir "Multiplicaci�n: ", multiplicacion
	Escribir "Division: ", division
FinAlgoritmo