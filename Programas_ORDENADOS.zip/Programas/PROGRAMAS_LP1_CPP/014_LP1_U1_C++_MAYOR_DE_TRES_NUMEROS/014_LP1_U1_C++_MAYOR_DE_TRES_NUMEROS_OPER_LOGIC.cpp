// Programa: Mayor de Tres Numeros (version con operadores logicos)
// Funcion : Solicita tres numeros y determina cual es el mayor usando operadores logicos (&&) en una estructura if/else if/else.
#include <iostream>
using namespace std;

int main() {
    int a, b, c;

    cout << "Ingrese el valor de A: ";
    cin >> a;
    cout << "Ingrese el valor de B: ";
    cin >> b;
    cout << "Ingrese el valor de C: ";
    cin >> c;

    if (a >= b && a >= c)
        cout << "El numero mayor es: " << a << endl;
    else if (b >= a && b >= c)
        cout << "El numero mayor es: " << b << endl;
    else
        cout << "El numero mayor es: " << c << endl;

    return 0;
}
